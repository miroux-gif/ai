# Content Publisher

A personal AI-powered content generation and publishing platform (MVP version) that runs entirely on your local machine — no external APIs or deployment required.

## Features

- **AI Content Generation** — Mock AI generates realistic content based on topic and tone
- **Draft Management** — Save content as drafts for later editing
- **Approval Workflow** — Review, approve, reject, or regenerate AI-generated content
- **Publishing** — Mock Facebook publisher with simulated metrics
- **Notifications** — Mock Telegram service for status updates
- **Simple Authentication** — Single-user login system
- **Local Database** — SQLite with Prisma ORM for data persistence
- **Fully Offline** — No external service dependencies

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Node.js + Express |
| Frontend | HTML + Tailwind CSS + Vanilla JS |
| Database | SQLite + Prisma ORM |
| AI | Mock generator (no API calls) |
| Notifications | Mock Telegram service |
| Publishing | Mock Facebook publisher |

## Project Structure

```
content-publisher/
├── backend/
│   ├── server.js                 # Express server entry point
│   ├── prisma/
│   │   ├── schema.prisma         # Database schema
│   │   └── seed.js               # Database seed script
│   ├── routes/
│   │   ├── auth.routes.js        # Authentication routes
│   │   ├── content.routes.js     # Content CRUD + workflow
│   │   ├── ai.routes.js          # AI generation endpoints
│   │   ├── publish.routes.js     # Publishing endpoints
│   │   └── notification.routes.js # Notification endpoints
│   ├── controllers/
│   │   ├── auth.controller.js
│   │   ├── content.controller.js
│   │   ├── ai.controller.js
│   │   ├── publish.controller.js
│   │   └── notification.controller.js
│   ├── services/
│   │   ├── ai.service.js         # Mock AI generator
│   │   ├── telegram.service.js   # Mock Telegram notifications
│   │   └── facebook.service.js   # Mock Facebook publisher
│   └── utils/
│       ├── auth.js               # JWT auth middleware
│       └── prisma.js             # Prisma client instance
├── frontend/
│   ├── index.html                # Login page
│   ├── dashboard.html            # Main dashboard
│   ├── pending.html              # Pending approvals
│   ├── assets/
│   │   └── styles.css            # Custom styles
│   └── scripts/
│       ├── app.js                # Shared utilities + API helpers
│       ├── dashboard.js          # Dashboard logic
│       └── pending.js            # Pending approvals logic
├── shared/
│   └── types.js                  # Shared type constants
├── .env.example                  # Environment variables template
├── package.json
└── README.md
```

## Quick Start (Local)

### Prerequisites

- [Node.js](https://nodejs.org/) 18+ installed
- npm (comes with Node.js)

### Step 1: Install Dependencies

```bash
npm install
```

### Step 2: Setup Environment

```bash
cp .env.example .env
```

The default `.env` values work out of the box for local development.

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | 3000 | Server port |
| `DATABASE_URL` | `file:./dev.db` | SQLite database path |
| `JWT_SECRET` | `your-super-secret-jwt-key...` | JWT signing key |
| `USER_EMAIL` | `admin@example.com` | Login email |
| `USER_PASSWORD` | `admin123` | Login password |

### Step 3: Initialize Database

```bash
npx prisma migrate dev --name init
```

This creates the SQLite database and applies the schema.

### Step 4: Seed Database (Optional)

```bash
npm run prisma:seed
```

Creates the default user and sample content.

### Step 5: Start the Server

```bash
npm start
```

The application will be available at:
- **Frontend**: http://localhost:3000
- **API Base**: http://localhost:3000/api

### Default Login Credentials

- **Email**: `admin@example.com`
- **Password**: `admin123`

## Development Mode

Run with auto-restart on file changes:

```bash
npm run dev
```
*(Requires `nodemon` which is installed as a dev dependency)*

## Prisma Commands

```bash
# Open Prisma Studio (visual database manager)
npm run prisma:studio

# Generate Prisma Client (after schema changes)
npm run prisma:generate

# Run migrations
npm run prisma:migrate

# Seed database
npm run prisma:seed
```

## Docker (Optional)

### Build and Run

```bash
docker build -t content-publisher .
docker run -p 3000:3000 content-publisher
```

### Using Docker Compose

```bash
docker-compose up
```

## API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login with email/password |
| GET | `/api/auth/me` | Get current user |

### Content
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/content` | Create content (or AI generate) |
| GET | `/api/content` | List all content |
| GET | `/api/content/stats` | Content statistics |
| GET | `/api/content/:id` | Get single content |
| PUT | `/api/content/:id` | Update content |
| DELETE | `/api/content/:id` | Delete content |
| POST | `/api/content/:id/approve` | Approve content |
| POST | `/api/content/:id/reject` | Reject content |
| POST | `/api/content/:id/regenerate` | Regenerate with AI |
| POST | `/api/content/:id/publish` | Publish to platform |

### AI
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/ai/generate` | Generate mock AI content |

### Notifications (Mock Telegram)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/notifications/send` | Send mock notification |

### Publishing (Mock Facebook)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/publish/facebook/:contentId` | Publish to Facebook (mock) |
| GET | `/api/publish/facebook/metrics/:postId` | Get mock metrics |

## Mock Services

### AI Generator
The AI service (`backend/services/ai.service.js`) generates realistic content based on:
- **Topic**: technology, health, business, marketing, lifestyle, travel, food, education
- **Tone**: professional, casual, humorous, inspirational, educational

No external API calls are made. Content is generated using template-based randomization.

### Telegram Notifications
The Telegram service (`backend/services/telegram.service.js`) logs notifications to the console with a formatted mock message. No real Telegram API calls are made.

### Facebook Publisher
The Facebook service (`backend/services/facebook.service.js`) simulates publishing with a random delay and returns mock post IDs and engagement metrics. No real Facebook API calls are made.

## Environment Variables

Create a `.env` file in the project root (copy from `.env.example`):

```env
PORT=3000
NODE_ENV=development
DATABASE_URL="file:./dev.db"
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
JWT_EXPIRES_IN=7d

# Mock service flags
ENABLE_MOCK_AI=true
ENABLE_MOCK_TELEGRAM=true
ENABLE_MOCK_FACEBOOK=true

# Single user credentials
USER_EMAIL=admin@example.com
USER_PASSWORD=admin123
```

## Pages

| Page | URL | Description |
|------|-----|-------------|
| Login | `/` or `/index.html` | Authentication |
| Dashboard | `/dashboard.html` | Generate content, view all content |
| Pending | `/pending.html` | Review AI-generated pending content |

## Database Schema

### User
- `id`, `email`, `name`, `password`, `createdAt`, `updatedAt`

### Content
- `id`, `title`, `body`, `topic`, `tone`, `status`, `platform`, `aiPrompt`, `aiResponse`, `publishedAt`, `createdAt`, `updatedAt`, `authorId`

Status values: `draft`, `pending`, `approved`, `rejected`, `published`

## Troubleshooting

### "Failed to fetch" or connection errors
Make sure the backend server is running on port 3000. The frontend expects the API at `http://localhost:3000/api`.

### Database errors
Run `npx prisma migrate dev` to ensure the database is initialized.

### Port already in use
Change the `PORT` in `.env` to another value (e.g., `PORT=3001`).

### Prisma Client not found
Run `npm run prisma:generate` to regenerate the Prisma client.

## License

MIT
