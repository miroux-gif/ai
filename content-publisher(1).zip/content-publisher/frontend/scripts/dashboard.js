// Dashboard specific logic

// Protect route
if (!isLoggedIn()) {
  window.location.href = 'index.html';
}

let currentGenerated = null;

// Load stats
async function loadStats() {
  try {
    const data = await apiGet('/content/stats');
    if (data.success) {
      const s = data.stats;
      document.getElementById('statTotal').textContent = s.total;
      document.getElementById('statDraft').textContent = s.draft;
      document.getElementById('statPending').textContent = s.pending;
      document.getElementById('statApproved').textContent = s.approved;
      document.getElementById('statPublished').textContent = s.published;
    }
  } catch (err) {
    console.error('Failed to load stats:', err);
  }
}

// Load contents
async function loadContents() {
  try {
    const statusFilter = document.getElementById('filterStatus').value;
    const query = statusFilter ? `?status=${statusFilter}` : '';
    const data = await apiGet(`/content${query}`);

    const list = document.getElementById('contentList');
    const empty = document.getElementById('emptyState');

    if (!data.success || !data.contents?.length) {
      list.innerHTML = '';
      empty.classList.remove('hidden');
      return;
    }

    empty.classList.add('hidden');
    list.innerHTML = data.contents.map(content => renderContentCard(content)).join('');
  } catch (err) {
    console.error('Failed to load contents:', err);
    showToast('Failed to load content', 'error');
  }
}

function renderContentCard(content) {
  return `
    <div class="bg-slate-900 rounded-xl border border-slate-800 p-5 hover:border-slate-700 transition-colors">
      <div class="flex items-start justify-between mb-3">
        <div class="flex items-center gap-3">
          <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(content.status)}">
            ${getStatusIcon(content.status)}
            ${content.status}
          </span>
          <span class="text-xs text-slate-500">${formatDate(content.createdAt)}</span>
        </div>
        <div class="flex items-center gap-1">
          ${content.status === 'approved' ? `
            <button onclick="publishContent(${content.id})" class="p-1.5 text-blue-400 hover:bg-blue-500/10 rounded-lg transition-colors" title="Publish">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
            </button>
          ` : ''}
          ${content.status === 'pending' ? `
            <button onclick="window.location.href='pending.html'" class="p-1.5 text-orange-400 hover:bg-orange-500/10 rounded-lg transition-colors" title="Review">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
            </button>
          ` : ''}
          <button onclick="deleteContent(${content.id})" class="p-1.5 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors" title="Delete">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
          </button>
        </div>
      </div>
      <h3 class="font-semibold text-white mb-2">${escapeHtml(content.title)}</h3>
      <p class="text-sm text-slate-400 line-clamp-3">${escapeHtml(content.body)}</p>
      ${content.platform ? `
        <div class="mt-3 flex items-center gap-2">
          <span class="text-xs text-slate-500">Platform:</span>
          <span class="text-xs text-slate-300">${content.platform}</span>
        </div>
      ` : ''}
    </div>
  `;
}

// Generate content
const generateForm = document.getElementById('generateForm');
generateForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = generateForm.querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.innerHTML = `<svg class="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path></svg> Generating...`;

  try {
    const topic = document.getElementById('topic').value;
    const tone = document.getElementById('tone').value;
    const customTitle = document.getElementById('customTitle').value;

    const data = await apiPost('/content', {
      topic,
      tone,
      title: customTitle || undefined,
      aiGenerate: true
    });

    if (data.success) {
      currentGenerated = data.content;
      document.getElementById('previewTitle').textContent = data.content.title;
      document.getElementById('previewBody').textContent = data.content.body;
      document.getElementById('generateResult').classList.remove('hidden');
      document.getElementById('generateError').classList.add('hidden');
      showToast('Content generated!', 'success');
      loadContents();
      loadStats();
    }
  } catch (err) {
    document.getElementById('generateError').textContent = err.message;
    document.getElementById('generateError').classList.remove('hidden');
    showToast(err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg> Generate Content`;
  }
});

// Save generated as draft
window.saveAsDraft = async function() {
  if (!currentGenerated) return;
  showToast('Already saved as draft', 'info');
};

// Submit for approval (from preview)
window.submitForApproval = async function() {
  if (!currentGenerated) return;
  // Already pending when AI generates
  showToast('Content is already pending approval', 'info');
  window.location.href = 'pending.html';
};

// Publish content
window.publishContent = async function(id) {
  try {
    const data = await apiPost(`/content/${id}/publish`);
    if (data.success) {
      showToast('Published to Facebook (mock)!', 'success');
      loadContents();
      loadStats();
    }
  } catch (err) {
    showToast(err.message, 'error');
  }
};

// Delete content
window.deleteContent = async function(id) {
  if (!confirm('Are you sure you want to delete this content?')) return;
  try {
    await apiDelete(`/content/${id}`);
    showToast('Content deleted', 'success');
    loadContents();
    loadStats();
  } catch (err) {
    showToast(err.message, 'error');
  }
};

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Init
loadStats();
loadContents();
