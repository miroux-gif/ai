// Shared utilities and API helpers for Content Publisher frontend

const API_BASE = 'http://localhost:3000/api';

// Auth helpers
function getToken() {
  return localStorage.getItem('token');
}

function setToken(token) {
  localStorage.setItem('token', token);
}

function getUser() {
  try {
    return JSON.parse(localStorage.getItem('user'));
  } catch {
    return null;
  }
}

function setUser(user) {
  localStorage.setItem('user', JSON.stringify(user));
}

function isLoggedIn() {
  return !!getToken();
}

function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  window.location.href = 'index.html';
}

// API helpers
async function api(endpoint, options = {}, requireAuth = true) {
  const url = `${API_BASE}${endpoint}`;
  const config = {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers
    },
    ...options
  };

  if (requireAuth) {
    const token = getToken();
    if (!token) {
      logout();
      throw new Error('Not authenticated');
    }
    config.headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(url, config);
  const data = await response.json().catch(() => null);

  if (!response.ok) {
    if (response.status === 401 || response.status === 403) {
      logout();
    }
    throw new Error(data?.error || `HTTP ${response.status}`);
  }

  return data;
}

function apiPost(endpoint, body, requireAuth = true) {
  return api(endpoint, {
    method: 'POST',
    body: JSON.stringify(body)
  }, requireAuth);
}

function apiGet(endpoint, requireAuth = true) {
  return api(endpoint, { method: 'GET' }, requireAuth);
}

function apiPut(endpoint, body, requireAuth = true) {
  return api(endpoint, {
    method: 'PUT',
    body: JSON.stringify(body)
  }, requireAuth);
}

function apiDelete(endpoint, requireAuth = true) {
  return api(endpoint, { method: 'DELETE' }, requireAuth);
}

// UI helpers
function showToast(message, type = 'info') {
  const toast = document.getElementById('toast');
  const toastMessage = document.getElementById('toastMessage');
  if (!toast || !toastMessage) return;

  toastMessage.textContent = message;

  const colors = {
    info: 'border-slate-700 bg-slate-800',
    success: 'border-green-500/30 bg-green-900/30 text-green-300',
    error: 'border-red-500/30 bg-red-900/30 text-red-300'
  };

  toast.className = `fixed bottom-6 right-6 px-6 py-3 rounded-xl shadow-2xl transform transition-all duration-300 z-50 ${colors[type] || colors.info}`;
  toast.classList.remove('translate-y-20', 'opacity-0');

  setTimeout(() => {
    toast.classList.add('translate-y-20', 'opacity-0');
  }, 3000);
}

function formatDate(dateString) {
  if (!dateString) return 'N/A';
  return new Date(dateString).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function getStatusColor(status) {
  const colors = {
    draft: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
    pending: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
    approved: 'bg-green-500/10 text-green-400 border-green-500/20',
    rejected: 'bg-red-500/10 text-red-400 border-red-500/20',
    published: 'bg-blue-500/10 text-blue-400 border-blue-500/20'
  };
  return colors[status] || 'bg-slate-500/10 text-slate-400 border-slate-500/20';
}

function getStatusIcon(status) {
  const icons = {
    draft: `<svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>`,
    pending: `<svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`,
    approved: `<svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>`,
    rejected: `<svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>`,
    published: `<svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>`
  };
  return icons[status] || '';
}

// Global logout handler
window.logout = logout;
window.showToast = showToast;
