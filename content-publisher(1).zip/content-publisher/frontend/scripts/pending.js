// Pending approvals page logic

// Protect route
if (!isLoggedIn()) {
  window.location.href = 'index.html';
}

async function loadPending() {
  try {
    const data = await apiGet('/content?status=pending');
    const list = document.getElementById('pendingList');
    const empty = document.getElementById('emptyState');
    const countEl = document.getElementById('pendingCount');

    if (!data.success || !data.contents?.length) {
      list.innerHTML = '';
      empty.classList.remove('hidden');
      countEl.textContent = '0';
      return;
    }

    empty.classList.add('hidden');
    countEl.textContent = data.contents.length;
    list.innerHTML = data.contents.map(content => renderPendingCard(content)).join('');
  } catch (err) {
    console.error('Failed to load pending:', err);
    showToast('Failed to load pending content', 'error');
  }
}

function renderPendingCard(content) {
  return `
    <div class="bg-slate-900 rounded-xl border border-slate-800 p-6" id="pending-${content.id}">
      <div class="flex items-start justify-between mb-4">
        <div class="flex items-center gap-3">
          <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border bg-orange-500/10 text-orange-400 border-orange-500/20">
            ${getStatusIcon('pending')}
            PENDING REVIEW
          </span>
          <span class="text-xs text-slate-500">${formatDate(content.createdAt)}</span>
        </div>
      </div>

      <h3 class="text-lg font-semibold text-white mb-3">${escapeHtml(content.title)}</h3>

      <div class="bg-slate-800/50 rounded-lg p-4 mb-5 border border-slate-800">
        <p class="text-sm text-slate-300 whitespace-pre-line">${escapeHtml(content.body)}</p>
      </div>

      <div class="flex items-center gap-3 mb-5 text-xs text-slate-500">
        ${content.topic ? `<span class="px-2 py-1 bg-slate-800 rounded">Topic: ${content.topic}</span>` : ''}
        ${content.tone ? `<span class="px-2 py-1 bg-slate-800 rounded">Tone: ${content.tone}</span>` : ''}
        ${content.platform ? `<span class="px-2 py-1 bg-slate-800 rounded">Platform: ${content.platform || 'none'}</span>` : ''}
      </div>

      <div class="flex flex-wrap items-center gap-3">
        <button onclick="approveContent(${content.id})"
          class="inline-flex items-center gap-2 px-4 py-2.5 bg-green-600 hover:bg-green-500 text-white font-medium rounded-lg transition-all transform hover:scale-[1.02] active:scale-[0.98]">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
          Approve
        </button>

        <button onclick="rejectContent(${content.id})"
          class="inline-flex items-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-500 text-white font-medium rounded-lg transition-all transform hover:scale-[1.02] active:scale-[0.98]">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          Reject
        </button>

        <button onclick="regenerateContent(${content.id})"
          class="inline-flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded-lg transition-all transform hover:scale-[1.02] active:scale-[0.98]">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
          Regenerate
        </button>

        <button onclick="editContent(${content.id})"
          class="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-white font-medium rounded-lg transition-all">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
          Edit
        </button>
      </div>
    </div>
  `;
}

window.approveContent = async function(id) {
  try {
    const data = await apiPost(`/content/${id}/approve`);
    if (data.success) {
      showToast('Content approved!', 'success');
      loadPending();
    }
  } catch (err) {
    showToast(err.message, 'error');
  }
};

window.rejectContent = async function(id) {
  try {
    const data = await apiPost(`/content/${id}/reject`);
    if (data.success) {
      showToast('Content rejected', 'info');
      loadPending();
    }
  } catch (err) {
    showToast(err.message, 'error');
  }
};

window.regenerateContent = async function(id) {
  if (!confirm('This will replace the current content with a new AI-generated version. Continue?')) return;

  const card = document.getElementById(`pending-${id}`);
  const btn = card?.querySelector('button[onclick^="regenerateContent"]');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = `<svg class="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path></svg> Regenerating...`;
  }

  try {
    const data = await apiPost(`/content/${id}/regenerate`);
    if (data.success) {
      showToast('Content regenerated!', 'success');
      loadPending();
    }
  } catch (err) {
    showToast(err.message, 'error');
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg> Regenerate`;
    }
  }
};

window.editContent = async function(id) {
  const newTitle = prompt('Edit title:');
  if (newTitle === null) return;

  const newBody = prompt('Edit body:');
  if (newBody === null) return;

  try {
    await apiPut(`/content/${id}`, {
      title: newTitle,
      body: newBody
    });
    showToast('Content updated', 'success');
    loadPending();
  } catch (err) {
    showToast(err.message, 'error');
  }
};

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Init
loadPending();
