// Mock Telegram Notification Service
// No real API calls - logs to console and returns mock response

const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function sendTelegramNotification(contentId, message) {
  const timestamp = new Date().toISOString();
  
  // Mock implementation - just log and return success
  console.log(`\n[TELEGRAM MOCK SERVICE] ${timestamp}`);
  console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
  console.log(`📨 To: @content_admin_channel`);
  console.log(`📋 Content ID: ${contentId}`);
  console.log(`💬 Message: ${message}`);
  console.log(`✅ Status: SENT (mock)`);
  console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`);

  // Optionally store notification log in database
  return {
    success: true,
    messageId: `mock-msg-${Date.now()}`,
    sentAt: timestamp,
    recipient: '@content_admin_channel',
    platform: 'telegram',
    contentPreview: message.substring(0, 100) + (message.length > 100 ? '...' : '')
  };
}

async function sendStatusUpdate(content) {
  const statusEmoji = {
    draft: '📝',
    pending: '⏳',
    approved: '✅',
    rejected: '❌',
    published: '🚀'
  };

  const message = `${statusEmoji[content.status] || '📄'} Content "${content.title}" is now ${content.status.toUpperCase()}`;
  
  return sendTelegramNotification(content.id, message);
}

module.exports = { sendTelegramNotification, sendStatusUpdate };
