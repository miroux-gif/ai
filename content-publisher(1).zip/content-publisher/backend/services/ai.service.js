// Mock AI Content Generator Service
// No external API calls - all local logic

const MOCK_TOPICS = [
  'technology', 'health', 'business', 'finance', 'lifestyle',
  'travel', 'food', 'sports', 'entertainment', 'science',
  'education', 'marketing', 'productivity', 'self-improvement'
];

const TONE_TEMPLATES = {
  professional: [
    "In today's rapidly evolving {topic} landscape, organizations must adapt to stay competitive.",
    "Recent developments in {topic} have significant implications for industry stakeholders.",
    "A comprehensive analysis of {topic} reveals key trends that demand attention."
  ],
  casual: [
    "Hey everyone! Let's talk about something cool happening in {topic} right now.",
    "So, I was checking out the latest in {topic} and wow, things are getting interesting!",
    "You won't believe what's going on in the world of {topic} lately!"
  ],
  humorous: [
    "Why did the {topic} expert cross the road? To optimize the other side, obviously!",
    "Breaking news in {topic}: Things are happening. Yes, actual things!",
    "If {topic} were a pizza, we'd all be fighting over the last slice right about now."
  ],
  inspirational: [
    "Believe in your ability to master {topic}. Every expert started as a beginner.",
    "The journey through {topic} is challenging, but the rewards are extraordinary.",
    "Embrace the possibilities that {topic} brings to your life and career."
  ],
  educational: [
    "Understanding {topic} begins with grasping the fundamental principles at play.",
    "Let's explore the key concepts that define {topic} in modern contexts.",
    "This guide to {topic} will provide practical insights for learners at all levels."
  }
};

const BODY_TEMPLATES = {
  professional: [
    "Key stakeholders are increasingly focused on strategic initiatives that drive measurable outcomes. The integration of innovative solutions continues to reshape traditional approaches, creating both opportunities and challenges for market participants.",
    "Data-driven decision making remains at the forefront of organizational priorities. By leveraging comprehensive analytics and market intelligence, leaders can identify emerging patterns and position their teams for sustained success.",
    "Industry experts emphasize the importance of continuous learning and adaptation. As regulatory frameworks evolve and consumer expectations shift, maintaining agility becomes essential for long-term viability."
  ],
  casual: [
    "Honestly, it's pretty wild how fast things are changing. I remember when this stuff was super niche, and now everyone's talking about it. Makes you wonder what's coming next, right?",
    "I've been following this for a while now, and the community around it is just amazing. So many people sharing ideas and helping each other out. That's the best part, if you ask me.",
    "Real talk? Some of this stuff is confusing at first, but once you get the hang of it, it's actually pretty straightforward. Just gotta take it step by step and not overthink it."
  ],
  humorous: [
    "Experts have studied this extensively, which is a fancy way of saying they Googled it really hard. The results? Inconclusive, but highly entertaining. Stay tuned for more vaguely scientific updates.",
    "Picture this: you're explaining this topic at a party. Eyes glaze over. Someone mentions pizza. Suddenly everyone cares again. That's the power of good analogies, people.",
    "Breaking analysis suggests that 9 out of 10 people who read this will nod thoughtfully while secretly thinking about lunch. The 10th person is already eating lunch. Congratulations, you data outlier."
  ],
  inspirational: [
    "Every challenge you face in this space is an opportunity to grow stronger and wiser. Remember that progress isn't always linear, but persistence always pays off in ways you can't always predict.",
    "Your potential in this area is limited only by the boundaries you set for yourself. Dream bigger, work harder, and trust that your efforts are building something meaningful even when you can't see the results yet.",
    "Success stories in this field all share a common thread: they never gave up. Not when it was hard, not when nobody believed in them, not even when they doubted themselves. That resilience is your greatest asset."
  ],
  educational: [
    "The core principles can be broken down into three main components: foundational theory, practical application, and ongoing evaluation. Mastering each layer creates a robust framework for continued development.",
    "Research indicates that active engagement with the material yields significantly better outcomes than passive consumption. Try implementing these concepts in small, controlled experiments to build confidence and competence.",
    "Important terminology to remember includes key metrics, standard methodologies, and commonly referenced frameworks. Building your vocabulary in this domain will accelerate your ability to collaborate with experienced practitioners."
  ]
};

function generateMockContent({ topic, tone = 'professional', title, count = 1 }) {
  const selectedTopic = topic || MOCK_TOPICS[Math.floor(Math.random() * MOCK_TOPICS.length)];
  const selectedTone = tone || 'professional';

  const results = [];
  for (let i = 0; i < count; i++) {
    const openers = TONE_TEMPLATES[selectedTone] || TONE_TEMPLATES.professional;
    const bodies = BODY_TEMPLATES[selectedTone] || BODY_TEMPLATES.professional;

    const opener = openers[Math.floor(Math.random() * openers.length)].replace(/{topic}/g, selectedTopic);
    const body = bodies[Math.floor(Math.random() * bodies.length)];

    const generatedTitle = title || generateTitle(selectedTopic, selectedTone);
    const fullBody = `${opener}\n\n${body}\n\n`;

    results.push({
      title: generatedTitle,
      body: fullBody,
      topic: selectedTopic,
      tone: selectedTone,
      generatedAt: new Date().toISOString(),
      id: `mock-${Date.now()}-${i}`
    });
  }

  return count === 1 ? results[0] : results;
}

function generateTitle(topic, tone) {
  const templates = {
    professional: [
      `Strategic Insights: The Future of ${capitalize(topic)}`,
      `${capitalize(topic)} Trends: What Leaders Need to Know`,
      `Navigating the ${capitalize(topic)} Landscape in 2024`
    ],
    casual: [
      `Let's Talk About ${capitalize(topic)}!`,
      `Why ${capitalize(topic)} Is Actually Pretty Cool`,
      `My Thoughts on ${capitalize(topic)} Right Now`
    ],
    humorous: [
      `${capitalize(topic)}: Explained With Questionable Accuracy`,
      `The ${capitalize(topic)} Tea Is Hot (And Possibly Spilled)`,
      `${capitalize(topic)} Experts Hate This One Simple Trick`
    ],
    inspirational: [
      `Unlock Your Potential in ${capitalize(topic)}`,
      `How ${capitalize(topic)} Changed My Perspective`,
      `The Courage to Master ${capitalize(topic)}`
    ],
    educational: [
      `${capitalize(topic)} 101: A Beginner's Guide`,
      `Understanding ${capitalize(topic)}: Key Concepts Explained`,
      `The Science Behind ${capitalize(topic)}`
    ]
  };

  const toneTemplates = templates[tone] || templates.professional;
  return toneTemplates[Math.floor(Math.random() * toneTemplates.length)];
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

module.exports = { generateMockContent };
