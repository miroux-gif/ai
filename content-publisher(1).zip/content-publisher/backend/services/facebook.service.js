// Mock Facebook Publisher Service
// No real API calls - logs to console and returns mock response

async function publishToFacebook(content) {
  const timestamp = new Date().toISOString();
  
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 800));

  console.log(`\n[FACEBOOK MOCK SERVICE] ${timestamp}`);
  console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
  console.log(`📘 Platform: Facebook Page (Mock)`);
  console.log(`📋 Content ID: ${content.id}`);
  console.log(`📝 Title: ${content.title}`);
  console.log(`📊 Content Length: ${content.body?.length || 0} characters`);
  console.log(`⏰ Published At: ${timestamp}`);
  console.log(`✅ Status: PUBLISHED (mock)`);
  console.log(`🔗 Mock URL: https://facebook.com/mock/posts/${Date.now()}`);
  console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`);

  return {
    success: true,
    postId: `fb-mock-${Date.now()}`,
    publishedAt: timestamp,
    platform: 'facebook',
    mockUrl: `https://facebook.com/mock/posts/${Date.now()}`,
    reach: Math.floor(Math.random() * 5000) + 100,
    impressions: Math.floor(Math.random() * 15000) + 500
  };
}

async function getFacebookMetrics(postId) {
  // Mock metrics for a published post
  return {
    postId,
    likes: Math.floor(Math.random() * 500),
    comments: Math.floor(Math.random() * 100),
    shares: Math.floor(Math.random() * 50),
    reach: Math.floor(Math.random() * 5000) + 100,
    impressions: Math.floor(Math.random() * 15000) + 500,
    updatedAt: new Date().toISOString()
  };
}

module.exports = { publishToFacebook, getFacebookMetrics };
