const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function seed() {
  console.log('🌱 Seeding database...');

  // Create default user if not exists
  const email = process.env.USER_EMAIL || 'admin@example.com';
  const password = process.env.USER_PASSWORD || 'admin123';

  let user = await prisma.user.findUnique({ where: { email } });

  if (!user) {
    user = await prisma.user.create({
      data: {
        email,
        password: await bcrypt.hash(password, 10),
        name: 'Admin User'
      }
    });
    console.log(`✅ Created default user: ${email}`);
  } else {
    console.log(`ℹ️ User already exists: ${email}`);
  }

  // Create sample content
  const sampleCount = await prisma.content.count({ where: { authorId: user.id } });

  if (sampleCount === 0) {
    const samples = [
      {
        title: 'Welcome to Content Publisher',
        body: 'This is your personal AI-powered content generation and publishing platform. Start by generating content from the dashboard.\n\nFeatures include:\n- AI-powered content generation (mock)\n- Draft management\n- Approval workflow\n- Publishing to Facebook (mock)\n- Telegram notifications (mock)',
        topic: 'getting-started',
        tone: 'professional',
        status: 'published',
        platform: 'blog',
        authorId: user.id
      },
      {
        title: 'Understanding AI Content Generation',
        body: 'AI content generation uses natural language processing to create human-like text. This platform demonstrates a mock implementation that produces realistic content for testing and development purposes.\n\nThe mock AI service generates content based on topic and tone parameters, giving you a realistic preview of how the system would work with a real AI API.',
        topic: 'technology',
        tone: 'educational',
        status: 'approved',
        platform: 'facebook',
        authorId: user.id
      },
      {
        title: '10 Tips for Better Social Media Content',
        body: '1. Know your audience\n2. Be consistent with posting\n3. Use engaging visuals\n4. Tell stories\n5. Ask questions\n6. Respond to comments\n7. Analyze your metrics\n8. Stay on trend\n9. Be authentic\n10. Have fun!',
        topic: 'marketing',
        tone: 'casual',
        status: 'pending',
        platform: 'facebook',
        authorId: user.id
      }
    ];

    for (const sample of samples) {
      await prisma.content.create({ data: sample });
    }
    console.log(`✅ Created ${samples.length} sample content items`);
  } else {
    console.log(`ℹ️ ${sampleCount} content items already exist`);
  }

  console.log('🌱 Seed complete!');
}

seed()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
