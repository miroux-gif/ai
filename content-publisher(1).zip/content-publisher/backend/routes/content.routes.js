const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../utils/auth');
const {
  createContent,
  getContents,
  getContent,
  updateContent,
  deleteContent,
  approveContent,
  rejectContent,
  regenerateContent,
  publishContent,
  getStats
} = require('../controllers/content.controller');

router.post('/', authenticateToken, createContent);
router.get('/', authenticateToken, getContents);
router.get('/stats', authenticateToken, getStats);
router.get('/:id', authenticateToken, getContent);
router.put('/:id', authenticateToken, updateContent);
router.delete('/:id', authenticateToken, deleteContent);
router.post('/:id/approve', authenticateToken, approveContent);
router.post('/:id/reject', authenticateToken, rejectContent);
router.post('/:id/regenerate', authenticateToken, regenerateContent);
router.post('/:id/publish', authenticateToken, publishContent);

module.exports = router;