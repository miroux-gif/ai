const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../utils/auth');
const { generate } = require('../controllers/ai.controller');

router.post('/generate', authenticateToken, generate);

module.exports = router;