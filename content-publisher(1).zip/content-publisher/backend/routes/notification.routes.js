const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../utils/auth');
const { sendNotification } = require('../controllers/notification.controller');

router.post('/send', authenticateToken, sendNotification);

module.exports = router;