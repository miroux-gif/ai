const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../utils/auth');
const { publish, getMetrics } = require('../controllers/publish.controller');

router.post('/facebook/:contentId', authenticateToken, publish);
router.get('/facebook/metrics/:postId', authenticateToken, getMetrics);

module.exports = router;