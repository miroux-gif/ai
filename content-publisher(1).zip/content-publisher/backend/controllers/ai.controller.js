const { generateMockContent } = require('../services/ai.service');

async function generate(req, res) {
  try {
    const { topic, tone, title, count = 1 } = req.body;

    const result = generateMockContent({ topic, tone, title, count });

    res.json({
      success: true,
      result,
      message: 'AI content generated successfully (mock)'
    });
  } catch (error) {
    console.error('AI generate error:', error);
    res.status(500).json({ error: 'Failed to generate content' });
  }
}

module.exports = { generate };
