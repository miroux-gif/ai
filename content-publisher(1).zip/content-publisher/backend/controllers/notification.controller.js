const { sendTelegramNotification } = require('../services/telegram.service');

async function sendNotification(req, res) {
  try {
    const { contentId, message } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const result = await sendTelegramNotification(contentId || 'manual', message);

    res.json({
      success: true,
      result,
      message: 'Notification sent (mock)'
    });
  } catch (error) {
    console.error('Notification error:', error);
    res.status(500).json({ error: 'Failed to send notification' });
  }
}

module.exports = { sendNotification };
