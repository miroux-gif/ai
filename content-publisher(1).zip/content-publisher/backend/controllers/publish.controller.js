const { publishToFacebook, getFacebookMetrics } = require('../services/facebook.service');

async function publish(req, res) {
  try {
    const { contentId } = req.params;
    const content = req.body; // content data passed from client

    const result = await publishToFacebook({
      id: contentId || content.id,
      title: content.title,
      body: content.body
    });

    res.json({
      success: true,
      result,
      message: 'Published to Facebook (mock)'
    });
  } catch (error) {
    console.error('Publish error:', error);
    res.status(500).json({ error: 'Failed to publish' });
  }
}

async function getMetrics(req, res) {
  try {
    const { postId } = req.params;
    const metrics = await getFacebookMetrics(postId);

    res.json({
      success: true,
      metrics
    });
  } catch (error) {
    console.error('Metrics error:', error);
    res.status(500).json({ error: 'Failed to fetch metrics' });
  }
}

module.exports = { publish, getMetrics };
