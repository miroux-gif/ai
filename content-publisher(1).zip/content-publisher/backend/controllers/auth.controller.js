const bcrypt = require('bcryptjs');
const { generateToken } = require('../utils/auth');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function login(req, res) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    // Check against env credentials (single user mode)
    const envEmail = process.env.USER_EMAIL || 'admin@example.com';
    const envPassword = process.env.USER_PASSWORD || 'admin123';

    if (email !== envEmail) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (password !== envPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Find or create user in database
    let user = await prisma.user.findUnique({ where: { email } });

    if (!user) {
      user = await prisma.user.create({
        data: {
          email: envEmail,
          password: await bcrypt.hash(envPassword, 10),
          name: 'Admin User'
        }
      });
    }

    const token = generateToken(user);

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
}

async function getMe(req, res) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.id },
      select: { id: true, email: true, name: true, createdAt: true }
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user });
  } catch (error) {
    console.error('Get me error:', error);
    res.status(500).json({ error: 'Failed to fetch user' });
  }
}

module.exports = { login, getMe };
