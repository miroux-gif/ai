// Shared types for Content Publisher
// Used by both backend and frontend

const ContentStatus = {
  DRAFT: 'draft',
  PENDING: 'pending',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  PUBLISHED: 'published'
};

const Platforms = {
  FACEBOOK: 'facebook',
  TELEGRAM: 'telegram',
  BLOG: 'blog'
};

const Tones = {
  PROFESSIONAL: 'professional',
  CASUAL: 'casual',
  HUMOROUS: 'humorous',
  INSPIRATIONAL: 'inspirational',
  EDUCATIONAL: 'educational'
};

// Export for both CommonJS and ES modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { ContentStatus, Platforms, Tones };
}
